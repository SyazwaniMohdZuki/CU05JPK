<?php 
//MAKLUMAT PANGKALAN DATA
$host='localhost';//NAMA SERVER LOCAL
$user='root';//	NAMA PENGGUNA PANGKALAN DATA
$password='';//TIADA KATALALUAN UNTUK PANGKALAN DATA
$dbname='barang';//NAMA PANGKALAN DATA
//SAMBUNGAN KE PANGKALAN DATA
$connect=mysqli_connect("localhost", "root","","barang") or die("failed...");
?>
