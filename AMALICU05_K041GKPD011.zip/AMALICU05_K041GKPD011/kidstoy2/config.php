<?php 
$connect=mysqli_connect("localhost:3306", "root","","barang") or die("failed...");//mendelete semula number pada ruang bersebelahan dengan root kerana tiada password perku diletakkan
?>
