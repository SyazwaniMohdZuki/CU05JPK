<?php 
//membuat sambungan ke database
$connect=mysqli_connect("localhost", "root","","barang") or die("failed...");
//pastikan nama database betul
?>
