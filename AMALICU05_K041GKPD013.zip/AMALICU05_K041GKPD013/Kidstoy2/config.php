<?php
//MAKLUMAT PANGKALAN DATA
$host='localhost';//NAMA SERVER LOCAL
$user='root';//	NAMA PENGGUNA PANGKALAN DATA
$password='';//TIADA KATALALUAN UNTUK PANGKALAN DATA
$dbname='barang';//NAMA PANGKALAN DATA
//SAMBUNGAN KE PANGKALAN DATA
$conn=mysqli_connect($host,$user,$password,$dbname) //membuat sambungan ke database
or die("database not connected");
?>