<html>
<head>
<title>UTAMA</title>


</style>

</head>

<body bgcolor="#FA5858">

	

<center><h1>KEDAI KEK OVERSEA</h1></center>
<img src="logo.jpg" width="100" height="100" float="left">
 <img src="banner.jpg" width="1300" height="100">


	<a href="index.php">UTAMA</a>
	<a href=""> HUBUNGI KAMI </a>

<center>
	<h2>Selamat datang ke Laman Web Oversea</h2>
	<br>
	<?php
//PANGGIL FAIL SAMBUNG KE PANGKALAN DATA
include("config1.php");
//MEMAPARKAN DATA KE DALAM JADUAL YANG DIBINA
if(isset($_POST['submit'])){
	$id=$_POST['id'];
	$komen=$_POST['komen'];
//Memasukkan maklumat ke dalam table barang
	$result=mysqli_query($conn, "INSERT INTO komen(komen) VALUES('$komen')");
//Memaparkan setelah data berjaya ditambah
	echo "<script> alert ('Tambah maklumat telah berjaya');"."window.location='pros_tambah1.php'</script>";
}
else
{

?>

<!DOCTYPE html>
<html>
<head>
	<title> Tambah  </title>
</head>
<body>
	<body bgcolor="#FA5858"><!--warna background-->
		<center>
			
	</center>
<center>
	<h1> Tambah rekod  maklumat  </h1>
	<fieldset> 
		<form method="post" action=" ">
		<table width="0%" border="1">
			<tr>
			</tr>
			<tr>
				<td>
				<h3> komen </h3></td>
				<td><input type="text" name="komen">	
				</td>
		</tr>
		<tr>
			<td></td>
				<td><input type="submit" name="submit" value="ADD">
			</td>
		</tr>
		</table>
	</form>
	<br> <a href="index.php"> kembali ke laman utama </a> <!--untuk pergi page index1.php-->
	</fieldset>
</center>
<?php } ?>
</body>
</html>
	<p>Maklum balas daripada pelanggan<p>
<a href="komen.php"> Senarai maklum balas </a>
<footer>
	<br>HUBUNGI KAMI<br>
Phone / 082-8878787<br>
Email /kekoversea@gmail.com<br>
© 2017<br>

</footer>
</center>




</header>

</body>


</html>