<html>
<head>
<title>UTAMA</title>


</style>

</head>

<body bgcolor="#FA5858">

	
<center><h1>KEDAI KEK OVERSEA</h1></center>
<img src="logo.jpg" width="100" height="100" float="left">
 <img src="banner.jpg" width="1300" height="100">


	<a href="index.php">UTAMA</a> &nbsp <a href=""> HUBUNGI KAMI </a>


<center>
	<h2>Selamat datang ke Laman Web Oversea</h2>
	<br>
	<img src="kek.jpg">
	<br>
	<p>Sila komen produk di <a href="pros_tambah1.php">sini</a></p>
	
	<p>Maklum balas daripada pelanggan<p>
<a href="komen.php"> Senarai maklum balas </a>
<footer>
	<P>HUBUNGI KAMI</P>
Phone / 082-8878787<br>
Email /kekoversea@gmail.com<br>
© 2017<br>

</footer>
</center>




</header>

</body>


</html>