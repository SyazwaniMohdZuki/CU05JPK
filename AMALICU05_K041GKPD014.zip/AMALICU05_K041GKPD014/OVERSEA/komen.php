<!DOCTYPE html>
<html>
<head>
	<title>KOMEN</title>
	<center>
<h2>SENARAI KOMEN</h2>
</head>
<body style = "background-color:#FA5858;">
   
		
		<table border="1" cellspacing="0" cellpadding="6">
		  <tr bgcolor="#eee">	

			<th>ID KOMEN</th>
			<th>KOMEN</th>
        		
			
		  </tr>

		  <?php
		  	include 'config1.php';

		  	$papar=mysqli_query($conn,"SELECT * FROM komen");

		  	while ($row=mysqli_fetch_array($papar)) {
		  		$totalRecord=mysqli_num_rows($papar);
		  		
		  echo "
		  <tr>	
			<td>".$row['idkomen']."</td>
			<td>".$row['komen']."</td>
        		</tr>";
		}
		  ?>

		</table>
		<br><br>
		
	</center>
<center><button><a href="index.php">kembali</button></center>
	
</body>
</html>