<?php
//host dalam komputer
$host = "localhost";
//server yang digunakan 
$server = "root";
//password untuk server
$password = "";
//database yang digunakan untuk projek ini
$dbase = "barang"; 
//sambungan untuk ke localhost dan database
$connect=mysqli_connect($host,$server,$password,$dbase) or die("failed...");
?>
