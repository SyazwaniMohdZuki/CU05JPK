<!DOCTYPE html>
<html>
<head>
	<title>PAGE NOT FOUND</title>
</head>
<body>
	<img src="123.jpg" width="100%">

</body>
</html>