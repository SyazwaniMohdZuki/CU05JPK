<?php 
$connect=mysqli_connect("localhost", "root","","barang") or die("failed...");
//padam number yang berada pada localhost
?>
